package com.example.mysmartcamera;


public enum MagicFilterType {
    NONE,
    WARM,
    ANTIQUE,
    COOL,
    BRANNAN,
    FREUD,
    HEFE,
    HUDSON,
    INKWELL,
    N1977,
    NASHVILLE,
}
